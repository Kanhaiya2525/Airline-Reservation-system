const AboutUs = () => {
  return (
    <div className="text-color ms-5 me-5 mr-5 mt-3">
      <b>MY ABOUT US COMPONENT</b>
    </div>
  );
};

export default AboutUs;
